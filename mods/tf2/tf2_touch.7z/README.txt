TF2 TOUCH / ТАЧ ДЛЯ TF2 
Copy "cfg" and "materials" folder to "tf_port" folder
Скопируй "cfg" и "materials" папки в "tf_port" папку
